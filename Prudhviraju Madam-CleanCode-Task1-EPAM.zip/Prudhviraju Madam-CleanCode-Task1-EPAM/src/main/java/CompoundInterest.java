public interface CompoundInterest {
    Double comPoundInterest();
}